# Customer Segmentation using Machine Learning

## Overview
This project uses machine learning to segment customers based on behavior and purchasing patterns.

## Objectives
- Identify customer groups
- Analyze spending behavior
- Generate business insights

## Pipeline
- Data Cleaning
- Feature Engineering
- Feature Scaling
- Clustering (KMeans, DBSCAN)
- Evaluation (Silhouette Score)
- Visualization (PCA)

## Models
- K-Means
- DBSCAN

## Technologies
- Python
- Pandas
- Scikit-learn
- Matplotlib

## Results
- Identified VIP customers, discount seekers, and growth opportunities

## Future Work
- Build dashboard using Streamlit
- Deploy as API
